{\rtf1\ansi\ansicpg1252\cocoartf1504\cocoasubrtf830
{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red203\green35\blue57;\red244\green246\blue249;\red87\green96\blue106;
\red7\green68\blue184;\red6\green33\blue79;\red91\green40\blue180;\red27\green31\blue34;\red218\green76\blue12;
}
{\*\expandedcolortbl;;\cssrgb\c84314\c22745\c28627;\cssrgb\c96471\c97255\c98039;\cssrgb\c41569\c45098\c49020;
\cssrgb\c0\c36078\c77255;\cssrgb\c1176\c18431\c38431;\cssrgb\c43529\c25882\c75686;\cssrgb\c14118\c16078\c18039;\cssrgb\c89020\c38431\c3529;
}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs23\fsmilli11900 \cf2 \cb3 \expnd0\expndtw0\kerning0
import\cf4  os\
\cf2 import\cf4  sys\
\cf2 import\cf4  time\
\cf2 import\cf4  json\
\cf2 import\cf4  pprint\
\
\cf2 from\cf4  instabot \cf2 import\cf4  Bot\
\
sys.path.append(os.path.join(sys.path[\cf5 0\cf4 ], \cf6 '../'\cf4 ))\
\
\cf5 COOKIE_FNAME\cf4  \cf2 =\cf4  \cf6 'cookie.txt'\cf4 \
\
\
\cf2 def\cf4  \cf7 _print_bot_last_state\cf4 (\cf8 bot\cf4 ):\
    \cf6 """Just pretty print the bot last state."""\cf4 \
    pprint.pprint(bot.last_response, \cf9 indent\cf2 =\cf5 4\cf4 )\
    pprint.pprint(bot.last_response.headers, \cf9 indent\cf2 =\cf5 4\cf4 )\
    pprint.pprint(bot.last_json, \cf9 indent\cf2 =\cf5 4\cf4 )\
    \
\
\cf2 def\cf4  \cf7 _get_challenge_choices\cf4 (\cf8 last_json\cf4 ):\
    \cf6 """Analise the Json response and get possible choices."""\cf4 \
    choices \cf2 =\cf4  []\
\
    # Checkpoint challenge\
    \cf2 if\cf4  last_json.get(\cf6 'step_name'\cf4 , \cf6 ''\cf4 ) \cf2 ==\cf4  \cf6 'select_verify_method'\cf4 :\
        choices.append(\cf6 "Checkpoint challenge received"\cf4 )\
        \cf2 if\cf4  \cf6 'phone_number'\cf4  \cf2 in\cf4  last_json[\cf6 'step_data'\cf4 ]:\
            choices.append(\cf6 '0 - Phone'\cf4 )\
        \cf2 if\cf4  \cf6 'email'\cf4  \cf2 in\cf4  last_json[\cf6 'step_data'\cf4 ]:\
            choices.append(\cf6 '1 - Email'\cf4 )\
\
    # Login alert challenge.\
    # \cf2 TODO\cf4 : TESTS NEEDED\
    \cf2 if\cf4  last_json.get(\cf6 'step_name'\cf4 , \cf6 ''\cf4 ) \cf2 ==\cf4  \cf6 'delta_login_review'\cf4 :\
        choices.append(\cf6 "Login attempt challenge received"\cf4 )\
        choices.append(\cf6 '0 - It was me'\cf4 )\
        choices.append(\cf6 '0 - It wasn\\'t me'\cf4 )\
\
    # If no choices found, use 1 as default.\
    # \cf2 TODO\cf4 : TESTS NEEDED\
    \cf2 if\cf4  \cf2 not\cf4  choices:\
        choices.append(\
            \cf6 '"\cf5 \{\}\cf6 " challenge received'\cf4 .format(\
                last_json.get(\cf6 'step_name'\cf4 , \cf6 'Unknown'\cf4 )))\
        choices.append(\cf6 '0 - Default'\cf4 )\
\
    \cf2 return\cf4  choices\
\
\
\cf2 def\cf4  \cf7 _reset_challenge\cf4 (\cf8 _bot\cf4 ):\
    \cf6 """Is recommended to reset the challenge at the beginning."""\cf4 \
    challenge_url \cf2 =\cf4  _bot.last_json[\cf6 'challenge'\cf4 ][\cf6 'api_path'\cf4 ][\cf5 1\cf4 :]\
    reset_url \cf2 =\cf4  challenge_url.replace(\cf6 '/challenge/'\cf4 , \cf6 '/challenge/reset/'\cf4 )\
    \cf2 try\cf4 :\
        _bot.send_request(reset_url, \cf9 login\cf2 =\cf5 True\cf4 )\
    \cf2 except\cf4  \cf5 Exception\cf4  \cf2 as\cf4  e:\
        _bot.logger.error(e)\
        \cf2 return\cf4  \cf5 False\cf4 \
    \cf2 return\cf4  \cf5 True\cf4 \
\
\
\cf2 def\cf4  \cf7 _solve_checkpoint_challenge\cf4 (\cf8 _bot\cf4 ):\
    \cf6 """Solve the annoying checkpoint_challenge"""\cf4 \
    # --- Start challenge\
    time.sleep(\cf5 3\cf4 )\
    challenge_url \cf2 =\cf4  _bot.last_json[\cf6 'challenge'\cf4 ][\cf6 'api_path'\cf4 ][\cf5 1\cf4 :]\
    \cf2 try\cf4 :\
        _bot.send_request(\
            challenge_url, \cf5 None\cf4 , \cf9 login\cf2 =\cf5 True\cf4 , \cf9 with_signature\cf2 =\cf5 False\cf4 )\
    \cf2 except\cf4  \cf5 Exception\cf4  \cf2 as\cf4  e:\
        _bot.logger.error(e)\
        \cf2 return\cf4  \cf5 False\cf4 \
\
    # --- Choose and send back the choice\
    # \cf2 TODO\cf4 : Sometimes ask to confirm phone or email. \
    # \cf2 TODO\cf4 : TESTS NEEDED\
    time.sleep(\cf5 3\cf4 )\
    choices \cf2 =\cf4  _get_challenge_choices(_bot.last_json)\
    \cf2 for\cf4  choice \cf2 in\cf4  choices:\
        \cf5 print\cf4 (choice)\
    code \cf2 =\cf4  \cf5 input\cf4 (\cf6 'Insert choice:\\n'\cf4 )\
    data \cf2 =\cf4  json.dumps(\{\cf6 'choice'\cf4 : code\})\
    \cf2 try\cf4 :\
        _bot.send_request(challenge_url, data, \cf9 login\cf2 =\cf5 True\cf4 )\
    \cf2 except\cf4  \cf5 Exception\cf4  \cf2 as\cf4  e:\
        _bot.logger.error(e)\
        \cf2 return\cf4  \cf5 False\cf4 \
\
    # Print output for testing\
    _print_bot_last_state(_bot)\
\
    # --- Wait for the code, insert the code\
    time.sleep(\cf5 3\cf4 )\
    \cf5 print\cf4 (\cf6 "A code has been sent to the method selected, please check."\cf4 )\
    code \cf2 =\cf4  \cf5 input\cf4 (\cf6 'Insert code:\\n'\cf4 )\
    data \cf2 =\cf4  json.dumps(\{\cf6 'security_code'\cf4 : code\})\
    \cf2 try\cf4 :\
        _bot.send_request(challenge_url, data, \cf9 login\cf2 =\cf5 True\cf4 )\
    \cf2 except\cf4  \cf5 Exception\cf4  \cf2 as\cf4  e:\
        _bot.logger.error(e)\
        \cf2 return\cf4  \cf5 False\cf4 \
\
    # Print output for testing\
    _print_bot_last_state(_bot)\
\
    # --- If user logged in, save cookie, otherwise PASS\
    worked \cf2 =\cf4  (\
        (\cf6 'logged_in_user'\cf4  \cf2 in\cf4  _bot.last_json)\
        \cf2 and\cf4  (_bot.last_json.get(\cf6 'action'\cf4 , \cf6 ''\cf4 ) \cf2 ==\cf4  \cf6 'close'\cf4 )\
        \cf2 and\cf4  (_bot.last_json.get(\cf6 'status'\cf4 , \cf6 ''\cf4 ) \cf2 ==\cf4  \cf6 'ok'\cf4 ))\
    \cf2 if\cf4  worked:\
        # IMPORTANT, save the cookie at this step!\
        _bot.save_cookie(\cf5 COOKIE_FNAME\cf4 )\
        \cf2 return\cf4  \cf5 True\cf4 \
    \cf2 else\cf4 :\
        _bot.logger.error(\cf6 'Not possible to log in. Reset and try again'\cf4 )\
        \cf2 return\cf4  \cf5 False\cf4 \
\
\
bot \cf2 =\cf4  Bot()\
\
\cf2 try\cf4 :\
    bot.login(\cf9 use_cookie\cf2 =\cf5 False\cf4 )\
    bot.logger.info(\cf6 'User logged successfully, no Challenge required'\cf4 )\
    \cf5 exit\cf4 ()\
\cf2 except\cf4  \cf5 Exception\cf4  \cf2 as\cf4  e:\
    bot.logger.error(e)\
    \cf2 if\cf4  bot.last_json.get(\cf6 'error_type'\cf4 , \cf6 ''\cf4 ) \cf2 ==\cf4  \cf6 'checkpoint_challenge_required'\cf4 :\
        \cf5 print\cf4 (\cf6 "Checkpoint_challenge found, attempting to solve..."\cf4 )\
        success \cf2 =\cf4  _solve_checkpoint_challenge(bot)\
        \cf2 if\cf4  success:\
            bot.login(\cf9 cookie_fname\cf2 =\cf5 COOKIE_FNAME\cf4 )\
    \cf2 else\cf4 :\
        \cf5 print\cf4 (\cf6 "Unknown challenge found, share the next output to get support"\cf4 )\
        _print_bot_last_state(bot)}